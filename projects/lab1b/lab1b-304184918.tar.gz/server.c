#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <mcrypt.h>
#include <sys/stat.h>

#define BUF_SIZE 1

pid_t pid;
static int encrypt_flag;
int sockfd, newsockfd, port_num;
MCRYPT cryptfd, decryptfd;
int fd0[2], fd1[2];

void exit1() {
  close(sockfd);
  close(newsockfd);
  exit(1);
}

void sigpipe_handler(){
  kill(pid, SIGKILL);
  exit(2);
}

char* read_key(char *filename)
{
  struct stat key_stat;

  int key_fd = open(filename, O_RDONLY);
  if(fstat(key_fd, &key_stat) < 0) { 
    perror("fstat"); 
    exit1(); 
  }
  char* key = (char*) malloc(key_stat.st_size * sizeof(char));

  if(read(key_fd, key, key_stat.st_size) < 0) { 
    perror("read"); 
    exit1(); 
  }
  return key;
}

void encrypt(char *buf, int crypt_len)
{
  if(mcrypt_generic(cryptfd, buf, crypt_len) != 0) 
  { 
    perror("Error in encryption"); 
    exit1(); 
  }
}

void decrypt(char *buf, int decrypt_len)
{
  if(mdecrypt_generic(decryptfd, buf, decrypt_len) != 0) 
  { 
    perror("Error in decryption"); 
    exit1(); 
  }
}

void *write_output(void *param)
{
  int *sockfd = (int *)param;
  int bytes_read;
  char buf[BUF_SIZE];

  while (1)
  {
    bytes_read = read(fd1[0], buf, 1);
    if(encrypt_flag)
      encrypt(buf,1);
    if(bytes_read > 0) 
      write(*sockfd,buf,1);
  }
  return NULL;
}

int main(int argc, char** argv) {
  int c;
  char buf[BUF_SIZE];
  unsigned int clilen;
  struct sockaddr_in serv_addr, cli_addr;

  static struct option longopts[] = {
    {"encrypt", no_argument, NULL , 'e'},
    {"port", required_argument, NULL, 'p'},
    {0, 0, 0, 0}
  };

  while(1) {
    int option_index = 0;
    c = getopt_long(argc, argv, "p:e", longopts, &option_index);
    if(c == -1)
      break;

    switch(c)
    {
      case 'p':
        port_num = atoi(optarg);
        break;
      case 'e':
        encrypt_flag = 1;
        char *key = read_key("my.key");
        cryptfd = mcrypt_module_open("blowfish", NULL, "ofb", NULL);
        if(cryptfd == MCRYPT_FAILED) { 
          perror("Error opening module"); 
          exit1(); 
        }
        if(mcrypt_generic_init(cryptfd, key, strlen(key), NULL) < 0) { 
          perror("Error while initializing encrypt");
          exit1(); 
        }
        decryptfd = mcrypt_module_open("blowfish", NULL, "ofb", NULL);
        if(decryptfd == MCRYPT_FAILED) { 
          perror("Error opening module"); 
          exit1(); 
        }
        if(mcrypt_generic_init(decryptfd, key, strlen(key), NULL) < 0) { 
          perror("Error while initializing decrypt");
          exit1(); 
        }
        break;
      default:
        exit1();
    }
  }

  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0) {
    perror("ERROR opening socket");
    exit1();
  }

  memset((char *) &serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = INADDR_ANY;
  serv_addr.sin_port = htons(port_num);

  if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
    perror("ERROR on binding");
    exit1();
  }

  listen(sockfd,5);
  clilen = sizeof(cli_addr);
  newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

  if (newsockfd < 0) {
    perror("ERROR on accept");
    exit1();
  }

  if(pipe(fd0) == -1) {
    perror("ERROR Pipe 0");
    exit1();
  }
  if(pipe(fd1) == -1) {
    perror("ERROR Pipe 1");
    exit1();
  }

  pid = fork();
  if(pid < 0)
  {
    perror("ERROR Fork");
    exit1();
  } else if (pid == 0) {
    close(fd0[1]);
    close(fd1[0]);
    dup2(fd0[0], STDIN_FILENO);
    dup2(fd1[1], STDOUT_FILENO);
    dup2(fd1[1], STDERR_FILENO);
    close(fd0[0]);
    close(fd1[1]);
    char *name[] = {
      "/bin/bash",
      NULL
    };
    if(execvp(name[0], name) == -1)
    {
      perror("ERROR exec");
      exit1();
    }
  } else {
    close(fd0[0]);
    close(fd1[1]);
    dup2(newsockfd, STDIN_FILENO);
    dup2(newsockfd, STDOUT_FILENO);
    dup2(newsockfd, STDERR_FILENO);
    int bytes_read;

    pthread_t output_thread;
    pthread_create(&output_thread, NULL, write_output, &newsockfd);

    while (1)
    {
      bytes_read = read (STDIN_FILENO, buf, 1);
      if(encrypt_flag)
        decrypt(buf, 1);
      if (*buf == 0x04)          /* C-d */
        exit1();
      if(bytes_read > 0) 
        write(fd0[1], buf, 1);
      else if(bytes_read == 0) 
        exit1();
    }
  }
  mcrypt_generic_deinit(cryptfd);
  mcrypt_module_close(cryptfd);
  mcrypt_generic_deinit(decryptfd);
  mcrypt_module_close(decryptfd);

  signal(SIGPIPE, sigpipe_handler);

  exit(0);
}



